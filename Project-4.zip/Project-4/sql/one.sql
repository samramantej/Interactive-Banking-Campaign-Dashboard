CREATE TABLE bank (
    age INT,
    job TEXT,
    marital TEXT,
    education TEXT,
    has_default BOOLEAN,
    balance FLOAT,
    housing TEXT,
    loan TEXT,
    contact TEXT,
    month TEXT,
    duration INT,
    campaign FLOAT,
    pdays INT,
    previous INT,
    poutcome TEXT,
    y TEXT,
    previous_contact INT
);
